// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float r = length(p);
    float a = atan(p.y, p.x);
    float n = floor(max(refP0, 4.0));
    float seg = 6.28318530718 / n;
    float k = floor(a / seg + 0.5);
    float ac = k * seg;
    // 乘以 r 使线条在内外圈等宽（否则越靠外越细）
    float ang = abs(a - ac) * max(r, 0.14);
    float w = max(refP1, 0.003);
    float v = 1.0 - ref_smoothstep(w * 0.35, w, ang);
    float r0 = max(refP2, 0.0);
    float r1 = max(refP3, r0 + 0.05);
    v *= ref_smoothstep(r0, r0 + 0.06, r);
    v *= 1.0 - ref_smoothstep(r1 - 0.10, r1, r);
    return clamp(v, 0.0, 1.0);
