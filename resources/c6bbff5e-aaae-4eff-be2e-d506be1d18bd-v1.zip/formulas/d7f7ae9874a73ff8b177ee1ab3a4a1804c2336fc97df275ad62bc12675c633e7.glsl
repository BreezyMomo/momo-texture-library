{
float petalCount = a.x;
float flowerScale = a.y;
float petalLength = a.z;
float petalWidth = a.w;
float petalOffset = b.x;
float petalPower = b.y;
float notchDepth = b.z;
float centerSize = b.w;
float holeSize = c.x;
float detailAmount = c.y;
float rotationDeg = c.z;
float softness = c.w;
{
vec2 p=q/max(flowerScale,0.01);
float n=floor(petalCount+0.5);
float rotation=rotationDeg*PI/180.0;
float dist=fxPetal(p,n,0.0,rotation,petalOffset,petalWidth,petalLength,petalPower);
vec2 local=fxPetalCoords(p,n,0.0,rotation);
float start=petalOffset+petalLength-notchDepth;
float cut=max(abs(local.x)-0.70*(local.y-start),start-local.y);
dist=max(dist,-cut);
dist=min(dist,length(p)-centerSize);
float mask=fxCover(dist,softness);
mask*=1.0-fxCover(length(p)-holeSize,softness)*detailAmount;
mask=max(mask,fxCover(length(p)-centerSize,softness));
return sat(mask);
}
}