// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float r = length(p);
    float a = mod(atan(p.y, p.x) + time * refP4, 6.28318530718);
    float r0 = max(refP1, 0.05);
    float r1 = max(refP2, r0 + 0.06);
    float rmid = (r0 + r1) * 0.5;
    float band = ref_smoothstep(r0, r0 + 0.02, r) * (1.0 - ref_smoothstep(r1 - 0.02, r1, r));
    float count = max(1.0, floor(6.28318530718 * rmid / max(refP3, 0.01) + 0.5));
    float cell = 6.28318530718 * rmid / count;
    float arc = a * rmid;
    float ci = mod(floor(arc / cell), count);
    float lc = fract(arc / cell) - 0.5;
    float bh = max(refP0, 0.006);
    float bw = cell * 0.42;
    float h1 = ref_hash1(vec2(ci, 1.7));
    float h2 = ref_hash1(vec2(ci, 4.3));
    float on = step(0.30, ref_hash1(vec2(ci, 9.7)));
    vec2 g = vec2(lc * cell, r - rmid);
    float v = ref_strokeD(ref_sdSeg(g, vec2(-bw, (h1 - 0.5) * bh * 2.0),
                            vec2(bw, (h1 - 0.5) * bh * 2.0)), 0.004, 0.003);
    v = max(v, ref_strokeD(ref_sdSeg(g, vec2((h2 - 0.5) * bw * 2.0, -bh),
                             vec2((h2 - 0.5) * bw * 2.0, bh)), 0.004, 0.003));
    v = max(v, ref_strokeD(ref_sdSeg(g, vec2(-bw * 0.8, -bh),
                             vec2(bw * 0.8, (h1 - 0.5) * bh)), 0.0035, 0.003));
    return clamp(v * on * band, 0.0, 1.0);
