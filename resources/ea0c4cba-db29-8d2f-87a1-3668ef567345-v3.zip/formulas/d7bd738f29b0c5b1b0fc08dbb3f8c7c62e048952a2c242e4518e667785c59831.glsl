// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float r = length(p);
    float a = atan(p.y, p.x);
    float n = floor(max(refP1, 1.0));
    float w = max(refP3, 0.002);
    float rmax = max(refP0, 0.15);
    float seg = 6.28318530718 / max(refP2, 2.0);
    float v = 0.0;
    for(int i = 0; i < 8; i++){
      if(float(i) >= n) break;
      float fi = float(i) + 1.0;
      float ri = rmax * fi / n;
      float dir = mod(fi, 2.0) > 0.5 ? 1.0 : -1.0;
      float aa = a + time * refP4 * dir * (0.6 + fi * 0.3) + ref_hash1(vec2(fi, 2.2)) * 6.28318530718;
      float g = fract(aa / seg);
      float arc = ref_smoothstep(0.07, 0.18, g) * (1.0 - ref_smoothstep(0.82, 0.93, g));
      v = max(v, (1.0 - ref_smoothstep(w * 0.6, w * 1.3, abs(r - ri))) * arc);
    }
    return clamp(v, 0.0, 1.0);
