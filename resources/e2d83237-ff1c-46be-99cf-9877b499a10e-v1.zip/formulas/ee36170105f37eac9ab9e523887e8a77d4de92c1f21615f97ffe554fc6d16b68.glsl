{
float petalCount = a.x;
float flowerScale = a.y;
float petalLength = a.z;
float petalWidth = a.w;
float petalOffset = b.x;
float petalPower = b.y;
float notchDepth = b.z;
float swirl = b.w;
float centerSize = c.x;
float detailAmount = c.y;
float rotationDeg = c.z;
float softness = c.w;
{
vec2 p=q/max(flowerScale,0.01);
float n=floor(petalCount+0.5);
float rotation=rotationDeg*PI/180.0;
float dist=fxPetal(p,n,swirl,rotation,petalOffset,petalWidth,petalLength,petalPower);
float heart=fxHeartPetal(p,n,swirl,rotation,petalOffset,petalWidth,petalLength);
dist=mix(dist,heart,clamp(notchDepth/0.055,0.0,1.0));
dist=min(dist,length(p)-centerSize);
float mask=fxCover(dist,softness);
float radius=length(p);
float theta=atan(p.y,p.x)-rotation+swirl*radius*2.0;
float seam=radius*abs(cos(theta*n*0.5))/max(n*0.5,1.0);
float seamWidth=0.018*(0.7+0.3*smoothstep(0.05,0.5,radius));
mask*=1.0-fxCover(seam-seamWidth,softness)*detailAmount;
return sat(mask);
}
}