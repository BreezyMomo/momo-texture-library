{
float petalCount = a.x;
float flowerScale = a.y;
float petalLength = a.z;
float petalWidth = a.w;
float petalOffset = b.x;
float petalPower = b.y;
float notchDepth = b.z;
float centerSize = b.w;
float detailAmount = c.x;
float rotationDeg = c.y;
float softness = c.z;
{
vec2 p=q/max(flowerScale,0.01);
float n=floor(petalCount+0.5);
float rotation=rotationDeg*PI/180.0;
float dist=fxPetal(p,n,0.0,rotation,petalOffset,petalWidth,petalLength,petalPower);
float heart=fxHeartPetal(p,n,0.0,rotation,petalOffset,petalWidth,petalLength);
dist=mix(dist,heart,clamp(notchDepth/0.055,0.0,1.0));
dist=min(dist,length(p)-centerSize);
float mask=fxCover(dist,softness);
float inner=fxPetal(p,n,0.0,rotation,0.38,0.033,0.17,2.0);
mask*=1.0-fxCover(inner,softness)*detailAmount;
return sat(mask);
}
}