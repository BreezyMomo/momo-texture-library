{
float petalCount = a.x;
float flowerScale = a.y;
float petalLength = a.z;
float petalWidth = a.w;
float petalOffset = b.x;
float petalPower = b.y;
float notchDepth = b.z;
float centerSize = b.w;
float holeSize = c.x;
float stamenCount = c.y;
float stamenLength = c.z;
float detailAmount = c.w;
float rotationDeg = d.x;
float softness = d.y;
{
vec2 p=q/max(flowerScale,0.01);
float n=floor(petalCount+0.5);
float rotation=rotationDeg*PI/180.0;
float dist=fxPetal(p,n,0.0,rotation,petalOffset,petalWidth,petalLength,petalPower);
float heart=fxHeartPetal(p,n,0.0,rotation,petalOffset,petalWidth,petalLength);
dist=mix(dist,heart,clamp(notchDepth/0.055,0.0,1.0));
dist=min(dist,length(p)-centerSize);
float mask=fxCover(dist,softness);
float stamens=fxStamens(p,floor(stamenCount+0.5),stamenLength,holeSize,rotation,0.000,0.005,0.015);
mask*=1.0-fxCover(stamens,softness)*detailAmount;
return sat(mask);
}
}