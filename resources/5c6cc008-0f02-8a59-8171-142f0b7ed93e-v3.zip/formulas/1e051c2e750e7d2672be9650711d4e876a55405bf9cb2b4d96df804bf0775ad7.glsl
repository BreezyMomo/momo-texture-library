// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    vec2 q = ref_rot2(uv - 0.5, refP2) + 0.5;
    vec2 s = q * vec2(refP0 * 0.35, refP0 * 3.2);
    float v = ref_fbmP(ref_warp(s, refP1, 1.0), 4, 0.5);
    return clamp((v - 0.5) * max(refP3, 0.2) * 2.2 + 0.5, 0.0, 1.0);
