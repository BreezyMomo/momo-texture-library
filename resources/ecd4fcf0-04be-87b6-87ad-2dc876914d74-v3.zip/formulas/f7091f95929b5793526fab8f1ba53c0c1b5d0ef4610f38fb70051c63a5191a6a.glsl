// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float r = length(p);
    float a = atan(p.y, p.x);
    float n = floor(max(refP0, 3.0));
    float seg = 6.28318530718 / n;
    float k = floor(a / seg + 0.5);
    float ac = k * seg;
    float r0 = max(refP1, 0.01);
    float r1 = max(refP2, r0 + 0.03);
    float rmid = (r0 + r1) * 0.5;
    float halfLen = (r1 - r0) * 0.5;
    float ang = (a - ac) * max(rmid, 0.06);
    float w = max(refP3, 0.0015);
    float d = length(vec2(max(abs(ang) - w, 0.0),
                          max(abs(r - rmid) - halfLen, 0.0)));
    return clamp(1.0 - ref_smoothstep(0.0, 0.005, d - 0.002), 0.0, 1.0);
