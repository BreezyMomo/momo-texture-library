{
float petalCount = a.x;
float flowerScale = a.y;
float petalLength = a.z;
float petalOffset = a.w;
float outlineWidth = b.x;
float centerSize = b.y;
float stamenCount = b.z;
float stamenLength = b.w;
float detailAmount = c.x;
float rotationDeg = c.y;
float softness = c.z;
{
vec2 p=q/max(flowerScale,0.01);
float n=floor(petalCount+0.5);
float rotation=rotationDeg*PI/180.0;
float theta=atan(p.y,p.x)-rotation;
float radius=petalOffset+petalLength+0.075*cos(n*theta)-0.018*cos(n*3.0*theta);
float dist=length(p)-radius;
float mask=fxCover(abs(dist)-outlineWidth,softness);
float stamens=fxStamens(p,floor(stamenCount+0.5),stamenLength,centerSize,rotation,0.000,0.008,0.021);
mask=max(mask,fxCover(stamens,softness)*detailAmount);
return sat(mask);
}
}