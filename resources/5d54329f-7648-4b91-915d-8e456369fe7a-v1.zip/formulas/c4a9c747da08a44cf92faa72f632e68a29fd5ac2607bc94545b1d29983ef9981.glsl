vec2 fxPetalCoords(vec2 p,float count,float twist,float rotation){
 float radius=length(p);float theta=atan(p.y,p.x)-rotation+twist*radius*2.0;
 float sector=6.28318530718/max(count,3.0);
 float folded=mod(theta+sector*0.5,sector)-sector*0.5;
 return vec2(radius*sin(folded),radius*cos(folded));
}
float fxPetal(vec2 p,float count,float twist,float rotation,float offset,float width,float height,float power){
 vec2 v=abs((fxPetalCoords(p,count,twist,rotation)-vec2(0.0,offset))/vec2(width,height));
 return (pow(pow(v.x,power)+pow(v.y,power),1.0/power)-1.0)*min(width,height);
}
float fxCover(float dist,float softness){float aa=max(fwidth(dist)*0.72,0.0006);return 1.0-smoothstep(-aa,aa+softness,dist);}
float fxStamens(vec2 p,float count,float lengthValue,float core,float rotation,float bend,float stemWidth,float dotRadius){
 vec2 v=fxPetalCoords(p,count,bend,rotation);
 return min(length(p)-core,min(segment(v,vec2(0.0,core*0.75),vec2(0.0,lengthValue))-stemWidth,length(v-vec2(0.0,lengthValue))-dotRadius));
}
float fxHeartDistance(vec2 p){
 p.x=abs(p.x);
 if(p.x+p.y>1.0)return length(p-vec2(0.25,0.75))-0.35355339;
 vec2 first=p-vec2(0.0,1.0);
 vec2 second=p-0.5*max(p.x+p.y,0.0);
 return sqrt(min(dot(first,first),dot(second,second)))*sign(p.x-p.y);
}
float fxHeartPetal(vec2 p,float count,float twist,float rotation,float offset,float width,float height){
 vec2 v=fxPetalCoords(p,count,twist,rotation);
 vec2 h=vec2(v.x*0.60355339/width,(v.y-offset+height)*1.10355339/(2.0*height));
 return fxHeartDistance(h)*min(width/0.60355339,2.0*height/1.10355339);
}