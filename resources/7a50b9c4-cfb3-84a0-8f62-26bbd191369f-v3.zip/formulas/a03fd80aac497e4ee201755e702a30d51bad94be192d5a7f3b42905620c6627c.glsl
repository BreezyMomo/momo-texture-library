
const float PI=3.14159265359;const float TAU=6.28318530718;
float sat(float x){return clamp(x,0.,1.);}vec2 rot(vec2 q,float a){float c=cos(a),s=sin(a);return mat2(c,-s,s,c)*q;}
float fill(float d,float s){return 1.-smoothstep(0.,max(s,.0001),d);}float line(float d,float w,float s){return 1.-smoothstep(w,w+max(s,.0001),abs(d));}
float hash21(vec2 p){p=fract(p*vec2(.1031,.11369));p+=dot(p,p.yx+19.19);return fract(p.x*p.y*(p.x+p.y));}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash21(i),hash21(i+vec2(1.,0.)),f.x),mix(hash21(i+vec2(0.,1.)),hash21(i+1.),f.x),f.y);}
vec2 grad(vec2 p){float a=hash21(p)*TAU;return vec2(cos(a),sin(a));}
float perlin(vec2 p){vec2 i=floor(p),f=fract(p),w=f*f*f*(f*(f*6.-15.)+10.);return mix(mix(dot(grad(i),f),dot(grad(i+vec2(1,0)),f-vec2(1,0)),w.x),mix(dot(grad(i+vec2(0,1)),f-vec2(0,1)),dot(grad(i+1.),f-1.),w.x),w.y)*1.7;}
float simplex(vec2 p){float f=(sqrt(3.)-1.)*.5,g=(3.-sqrt(3.))/6.;vec2 i=floor(p+dot(p,vec2(f)));vec2 a=p-i+dot(i,vec2(g));vec2 j=a.x>a.y?vec2(1,0):vec2(0,1);vec2 b=a-j+g,c=a-1.+2.*g;vec3 w=max(vec3(.5-dot(a,a),.5-dot(b,b),.5-dot(c,c)),vec3(0));w*=w;w*=w;return 70.*dot(w,vec3(dot(grad(i),a),dot(grad(i+j),b),dot(grad(i+1.),c)));}
float fbm(vec2 p){float v=0.,w=.5;for(int i=0;i<5;i++){v+=w*noise(p);p=rot(p,.47)*2.03+13.7;w*=.5;}return v/ .96875;}
float fractalValue(vec2 p,int octaves,float gain){float v=0.,w=1.,sum=0.;for(int i=0;i<8;i++){if(i>=octaves)break;v+=w*noise(p);sum+=w;p=rot(p,.47)*2.03+13.7;w*=gain;}return v/max(sum,.00001);}
float checker(vec2 u,float count,float soft){vec2 p=u*count,f=fract(p);float c=mod(floor(p.x)+floor(p.y),2.);float edge=min(min(f.x,1.-f.x),min(f.y,1.-f.y));return mix(.5,c,smoothstep(0.,max(soft,.00001),edge));}
float brick(vec2 u,float columns,float rows,float mortar,float offset,float soft){vec2 p=u*vec2(columns,rows);float row=floor(p.y);p.x+=mod(row,2.)*offset;vec2 f=fract(p),distance=min(f,1.-f);float edge=min(distance.x,distance.y);return smoothstep(mortar*.5,mortar*.5+max(soft,.00001),edge);}
float turb(vec2 p){float v=0.,w=.5;for(int i=0;i<5;i++){v+=w*abs(perlin(p));p=rot(p,.31)*2.1+11.;w*=.5;}return sat(v*1.5);}
vec3 voronoi(vec2 p,float seed){vec2 i=floor(p),f=fract(p);float a=10.,b=10.,id=0.;for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){vec2 o=vec2(x,y),h=vec2(hash21(i+o+seed),hash21(i+o+seed+9.));float d=length(o+h-f);if(d<a){b=a;a=d;id=hash21(i+o+seed);}else b=min(b,d);}return vec3(a,b-a,id);}
vec2 curl(vec2 q){float e=.04;return vec2(fbm(q+vec2(0,e))-fbm(q-vec2(0,e)),-fbm(q+vec2(e,0))+fbm(q-vec2(e,0)))/(2.*e);}
float box(vec2 p,vec2 b,float r){vec2 d=abs(p)-b+r;return length(max(d,0.))+min(max(d.x,d.y),0.)-r;}
float poly(vec2 q,float n,float r){n=max(3.,floor(n));float a=atan(q.y,q.x),sector=TAU/n;return cos(floor(.5+a/sector)*sector-a)*length(q)-r;}
float segment(vec2 p,vec2 a,vec2 b){vec2 q=p-a,v=b-a;return length(q-v*clamp(dot(q,v)/max(dot(v,v),.00001),0.,1.));}
float starDistance(vec2 p,float count,float radius,float ratio,float rounding){float corner=min(rounding,radius*.45),r=radius-corner,halfAngle=PI/count;float angle=abs(mod(atan(p.x,p.y)+halfAngle,2.*halfAngle)-halfAngle);vec2 q=length(p)*vec2(sin(angle),cos(angle));vec2 a=vec2(0,r),b=r*ratio*vec2(sin(halfAngle),cos(halfAngle)),edge=b-a;float side=dot(q-a,vec2(-edge.y,edge.x));return segment(q,a,b)*(side>0.?1.:-1.)-corner;}
vec2 profilePoint(float t,float side,float r,float w,float power,float bend,float skew,int leaf){float y=-cos(PI*t);float width=leaf==1?pow(max(cos(PI*y*.5),0.),power):sqrt(max(1.-y*y,0.))*pow(max(1.-y,0.),power)/pow(1.4,power);return vec2(bend*r*(1.-y*y)+side*w*width*(1.+skew*y),r*y);}
float profileShape(vec2 p,float r,float w,float power,float bend,float skew,int leaf){float distance=10.;vec2 left=profilePoint(0.,-1.,r,w,power,bend,skew,leaf),right=profilePoint(0.,1.,r,w,power,bend,skew,leaf);for(int j=1;j<=32;j++){float t=float(j)/32.;vec2 l=profilePoint(t,-1.,r,w,power,bend,skew,leaf),h=profilePoint(t,1.,r,w,power,bend,skew,leaf);distance=min(distance,min(segment(p,left,l),segment(p,right,h)));left=l;right=h;}float phase=acos(clamp(-p.y/r,-1.,1.))/PI*32.;float cell=min(floor(phase),31.);float y0=profilePoint(cell/32.,-1.,r,w,power,bend,skew,leaf).y,y1=profilePoint((cell+1.)/32.,-1.,r,w,power,bend,skew,leaf).y;float f=clamp((p.y-y0)/max(y1-y0,.0000001),0.,1.);float lo=mix(profilePoint(cell/32.,-1.,r,w,power,bend,skew,leaf).x,profilePoint((cell+1.)/32.,-1.,r,w,power,bend,skew,leaf).x,f),hi=mix(profilePoint(cell/32.,1.,r,w,power,bend,skew,leaf).x,profilePoint((cell+1.)/32.,1.,r,w,power,bend,skew,leaf).x,f);return abs(p.y)<=r&&p.x>=lo&&p.x<=hi?-distance:distance;}
vec2 cubicPoint(vec4 a,vec4 b,float t){float s=1.-t;return s*s*s*a.xy+3.*s*s*t*a.zw+3.*s*t*t*b.xy+t*t*t*b.zw;}
vec2 cubicTangent(vec4 a,vec4 b,float t){float s=1.-t;return 3.*s*s*(a.zw-a.xy)+6.*s*t*(b.xy-a.zw)+3.*t*t*(b.zw-b.xy);}
float ribbonShape(vec2 p,vec4 a,vec4 b,vec4 c,vec4 d){if(c.w<=0.)return 0.;float distance=10.,nearest=0.;vec2 start=a.xy,previous=start;float before=0.;for(int j=1;j<=48;j++){float t=float(j)/48.*c.w;vec2 next=cubicPoint(a,b,t),v=next-previous;float h=clamp(dot(p-previous,v)/max(dot(v,v),.0000001),0.,1.);float at=mix(before,t,h),candidate=length(p-previous-v*h)-mix(c.x,c.y,at)*.5;if(candidate<distance){distance=candidate;nearest=at;}previous=next;before=t;}if(d.x>.5){vec2 first=cubicTangent(a,b,0.),last=cubicTangent(a,b,c.w);if(nearest<.000001)distance=max(distance,-dot(p-start,normalize(first+vec2(.000001,0))));if(nearest>c.w-.000001)distance=max(distance,dot(p-previous,normalize(last+vec2(.000001,0))));}return fill(distance,c.z);}
// Tooth width is a fraction of one pitch; top ratio zero forms a point, one a square tooth.
// Continuous union of the root disk and a folded trapezoid. Differentiating
// r-gearRadius across a square tooth's angular boundary creates false inner edges.
float gearDistance(vec2 p,float n,float radius,float depth,float width,float top){
 float sector=TAU/n,angle=abs(mod(atan(p.y,p.x),sector)-sector*.5);
 float halfAngle=PI*width/n,root=max(radius-depth,.001),topAngle=halfAngle*top;
 vec2 q=length(p)*vec2(sin(angle),cos(angle));
 vec2 base=root*vec2(sin(halfAngle),cos(halfAngle));
 vec2 tip=radius*vec2(sin(topAngle),cos(topAngle)),edge=tip-base;
 float side=(edge.y*(q.x-base.x)-edge.x*(q.y-base.y))/max(length(edge),.0000001);
 // Extend the tooth into the disk within its angular wedge. A bottom chord
 // leaves a shallow internal distance ridge that antialiasing exposes as a seam.
 float wedge=q.x*cos(halfAngle)-q.y*sin(halfAngle);
 float tooth=max(max(wedge,q.y-tip.y),side);
 return min(length(p)-root,tooth);
}
float gearRadius(float a,float n,float radius,float depth,float width,float top){float sector=TAU/n;float beta=abs(mod(a,sector)-sector*.5);float halfAngle=PI*width/n;float root=max(radius-depth,.001);if(beta>=halfAngle)return root;float topAngle=halfAngle*top;vec2 base=root*vec2(sin(halfAngle),cos(halfAngle));vec2 tip=radius*vec2(sin(topAngle),cos(topAngle));if(beta<=topAngle)return max(root,tip.y/cos(beta));vec2 edge=tip-base;vec2 ray=vec2(sin(beta),cos(beta));return max(root,(base.x*edge.y-base.y*edge.x)/max(ray.x*edge.y-ray.y*edge.x,.000001));}
// Exact contour distance: upper circular lobes join lower diagonal segments.
// Unlike a polynomial threshold, the distance has uniform feathering at the tip.
float heart(vec2 q,float r){float scale=max(r,.02)*1.75;vec2 p=vec2(abs(q.x),q.y)/scale+vec2(0.,.55);if(p.x+p.y>1.)return (length(p-vec2(.25,.75))-sqrt(.125))*scale;vec2 notch=p-vec2(0.,1.);vec2 edge=p-vec2(.5*max(p.x+p.y,0.));float d=sqrt(min(dot(notch,notch),dot(edge,edge)));return d*sign(p.x-p.y)*scale;}
float grid(vec2 p,float w,float s){vec2 d=abs(fract(p)-.5);return line(max(d.x,d.y)-.5,w,s);}
vec2 hexcell(vec2 p){p*=vec2(1.,1.7320508);vec2 a=mod(p,vec2(1.,1.7320508))-.5*vec2(1.,1.7320508),b=mod(p-.5*vec2(1.,1.7320508),vec2(1.,1.7320508))-.5*vec2(1.,1.7320508);vec2 q=dot(a,a)<dot(b,b)?a:b;return vec2(abs(max(abs(q.x),abs(q.x)*.5+abs(q.y)*.8660254)-.5),length(q));}
float spots(vec2 p,float radius,float soft){vec2 i=floor(p),f=fract(p);float v=0.;for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){vec2 o=vec2(x,y);vec2 c=vec2(hash21(i+o),hash21(i+o+37.));v=max(v,fill(length(f-o-c)-radius*(.3+.7*hash21(i+o+4.)),soft));}return v;}
float metaball(vec2 q,float r,float t){float sum=0.;for(int i=0;i<5;i++){float a=float(i)*TAU/5.+t;vec2 c=vec2(cos(a),sin(a*1.3))*r*.5;sum+=r*r*.04/max(dot(q-c,q-c),.003);}return smoothstep(.9,1.1,sum);}
float truchet(vec2 p,float w,float s,float h){vec2 i=floor(p),q=fract(p);if(hash21(i+h)>.5)q.x=1.-q.x;return max(line(length(q)-.5,w,s),line(length(q-1.)-.5,w,s));}
float circuit(vec2 p,float w,float s,float h){vec2 i=floor(p),q=fract(p)-.5;float v=line(q.x,w,s)*fill(q.y,s);if(hash21(i+h)>.5)v=max(v,line(q.y,w,s));return max(v,line(length(q)-.14,w,s));}
float fibonacci(vec2 q,int count,float r,float w,float s){float v=0.;for(int i=0;i<256;i++){if(i>=count)break;float n=float(i);vec2 c=r*sqrt((n+.5)/float(count))*vec2(cos(n*2.39996323),sin(n*2.39996323));v=max(v,fill(length(q-c)-w,s));}return v;}
float sierpinski(vec2 p,int n){float v=1.;p*=float(n);for(int i=0;i<6;i++){if(mod(floor(p.x)+floor(p.y),2.)>0.5)v=0.;p*=.5;}return v;}
float maze(vec2 p,float w,float s,float h){vec2 i=floor(p),q=fract(p)-.5;return hash21(i+h)>.5?line(q.x,w,s):line(q.y,w,s);}
float reaction(vec2 q,float h,float t,float k){vec2 uv=q;for(int i=0;i<4;i++)uv+=curl(uv+h+float(i))*.08*k;float v=fbm(uv+t*.1);return .5+.5*sin(v*25.+h);}
float flame(vec2 q,float r,float n,float k,float t,float h){float height=sat((q.y+r)/(2.*r));float warp=(fbm(q*n+vec2(0.,-t*2.)+h)-.5)*k;return pow(sat(1.-abs(q.x+warp)/(r*max(.03,1.-height))),1.5)*sat(height*4.)*pow(1.-height,.5)*(.5+.5*fbm(q*n+vec2(0.,-t)+h));}
float caustic(vec2 p,float h,float w){float v=1.;for(int i=0;i<3;i++){p=rot(p,.71)+vec2(sin(p.y),cos(p.x));v=min(v,abs(sin(p.x+sin(p.y+h))));p*=1.3;}return pow(1.-sat(v),8.)+line(v,w,.01)*.3;}
float fern(vec2 q,float r,float n,float w,float s){float v=line(q.x,w,s)*fill(abs(q.y)-r,s);for(int i=0;i<16;i++){if(float(i)>=n)break;float y=(float(i)/n*2.-1.)*r;float len=(1.-abs(y)/r)*r*.5;v=max(v,line(segment(q,vec2(0,y),vec2(len,y+.2)),w*.4,s));v=max(v,line(segment(q,vec2(0,y),vec2(-len,y+.2)),w*.4,s));}return v;}
float snowflake(vec2 q,float r,float n,float w,float s){float a=atan(q.y,q.x);a=abs(mod(a+PI/6.,PI/3.)-PI/6.);vec2 p=vec2(cos(a),sin(a))*length(q);float v=line(p.y,w,s)*fill(p.x-r,s);for(int i=1;i<8;i++){float x=float(i)*r/8.;v=max(v,line(segment(p,vec2(x,0),vec2(x-r*.13,r*.13)),w*.5,s));}return v;}
float droplets(vec2 p,float h,float w,float s){vec2 i=floor(p),q=fract(p)-vec2(hash21(i+h),hash21(i+h+9.));return line(length(q)-.18,w,s)*exp(-length(q)*2.)+line(q.x,w*.25,s)*fill(abs(q.y)-.4,s)*.3;}
float matrix(vec2 p,float h,float t){vec2 i=floor(p),q=fract(p)-.5;float v=step(.5,hash21(i+h))*max(line(q.x,.05,.02),line(q.y,.04,.02));float head=fract(i.x*.137+t*.3);return v*sat(1.-fract(p.y*.08-head)*2.);}
float qr(vec2 p,float h){vec2 q=fract(p/8.);float v=step(.5,hash21(floor(p)+h));for(int i=0;i<3;i++){vec2 c=i==0?vec2(.2):i==1?vec2(.8,.2):vec2(.2,.8);float d=max(abs(q.x-c.x),abs(q.y-c.y));if(d<.15)v=step(.10,d)+1.-step(.055,d);}return v;}
float bolt(vec2 q,float w,float n,float k,float t,float h){float x=(noise(vec2(q.y*n,floor(t*8.)+h))-.5)*k;return exp(-abs(q.x-x)/max(w,.001))+exp(-abs(q.x-x)/(w*4.))*.25;}
float pyro(vec2 q,float r,float n,float w,float s,float t,float h){float age=fract(t);float a=atan(q.y,q.x),rad=length(q);float ray=pow(sat(cos(a*n)),24.);return ray*exp(-pow((rad-r*age)/(w*4.+.01),2.))*(1.-age)+spots(q*n+h,r*.05,s)*exp(-rad/r)*(1.-age)*.2;}
float ribbon(vec2 q,float r,float w,float n,float d,float k,float t,float h,int mode){float y=sat((q.y+1.)*.5),x=q.x;float width=r*.4;float base=exp(-abs(x)/(width+.001))*pow(y,.5+d*3.);if(mode==1)return fill(abs(x)-width*y,.02)*y;
if(mode==2)return base+exp(-abs(x)/w)*y;if(mode==3)return base*pow(.5+.5*sin(x*n*TAU+k*fbm(q*n+t)*8.),3.);
if(mode==4)return base*line(sin(x*n*PI+fbm(q*n+t)*k*8.),w*4.,.01);
if(mode==5)return base*pow(y,4.)+spots(q*n+h,r*.05,.01)*y;
if(mode==6)return exp(-abs(x)/w)*y+exp(-abs(x)/(w*5.))*y*.3;
if(mode==7)return base*flame(vec2(x,q.y),r,n,k,t,h);
if(mode==8)return base*pow(fbm(q*n+vec2(0,-t)+h),2.);
if(mode==9)return spots(q*vec2(n,n*.5)+vec2(0,-t)+h,r*.06,.01)*y*exp(-abs(x)/width);
if(mode==10)return line(length(q-vec2(-r,0))-r,w,.02)*fill(abs(q.y)-r,.02)*y;
if(mode==11)return max(max(exp(-abs(x-width*.5)/w),exp(-abs(x)/w)),exp(-abs(x+width*.5)/w))*pow(y,2.);
if(mode==12)return exp(-abs(x-k*.2*sin(q.y*n-t))/max(w*4.,.01))*y;
if(mode==13)return base*(.5+.5*sin(q.y*n*TAU+abs(x)*n-t))*y;
if(mode==14)return base*pow(noise(q*vec2(n*2.,n*.2)+t),5.);
if(mode==15)return base*spots(q*n+vec2(0,-t)+h,r*.08,.01);return base;}
float sigil(vec2 q,float r,float n,float w,float s,float mode,float t,float h){q=rot(q,t*.15);float rad=length(q),a=atan(q.y,q.x),outer=line(rad-r,w,s);float ticks=line(sin(a*n),w*4.,s)*fill(abs(rad-r*.9)-r*.07,s);float polygon=line(poly(q,max(3.,n),r*.65),w,s);float glyph=line(sin(a*n*2.+floor(rad*n)*h),w*3.,s)*fill(abs(rad-r*.78)-r*.06,s);
if(mode<.5)return outer+line(rad-r*.75,w*.5,s)+line(rad-r*.5,w,s);
if(mode<1.5)return outer+ticks;if(mode<2.5)return outer+line(sin(a*n),w*3.,s)*fill(rad-r,s);
if(mode<3.5)return outer+pow(sat(cos(a*n)),16.)*fill(rad-r,s);
if(mode<4.5)return outer+polygon+line(poly(rot(q,PI/max(3.,n)),max(3.,n),r*.65),w,s);
if(mode<5.5)return outer+line(poly(q,3.,r*.7),w,s)+line(poly(-q,3.,r*.7),w,s);
if(mode<6.5)return outer+line(box(q,vec2(r*.5),0.),w,s)+line(box(rot(q,PI/4.),vec2(r*.5),0.),w,s);
if(mode<7.5)return line(sin(rad*n*PI),w*2.,s)*fill(rad-r,s)+ticks;
if(mode<8.5)return outer+glyph;if(mode<9.5)return glyph+line(rad-r*.84,w,s)+line(rad-r*.72,w,s);
if(mode<10.5)return outer+glyph*step(.4,hash21(vec2(floor(a*n),h)))+polygon;
if(mode<11.5)return outer*fbm(q*n+t)*2.+glyph+flame(q,r,n,.3,t,h)*.3;
if(mode<12.5)return outer+snowflake(q,r*.7,n,w*.7,s)+ticks;
if(mode<13.5)return outer+polygon+line(hexcell(q*n).x,w,s)*fill(rad-r*.65,s)*.4;
if(mode<14.5)return outer+ticks+glyph+polygon+line(rad-r*.4,w,s);
return outer+line(sin(a+rad*n-t),w*3.,s)*fill(rad-r,s);}
