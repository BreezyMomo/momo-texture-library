{
float petalCount = a.x;
float flowerScale = a.y;
float petalLength = a.z;
float petalWidth = a.w;
float petalOffset = b.x;
float petalPower = b.y;
float centerSize = b.z;
float holeSize = b.w;
float detailAmount = c.x;
float rotationDeg = c.y;
float softness = c.z;
{
vec2 p=q/max(flowerScale,0.01);
float n=floor(petalCount+0.5);
float rotation=rotationDeg*PI/180.0;
float dist=fxPetal(p,n,0.0,rotation,petalOffset,petalWidth,petalLength,petalPower);
dist=min(dist,length(p)-centerSize);
float mask=fxCover(dist,softness);
float inner=fxPetal(p,n,0.0,rotation,0.18,0.033,0.17,1.6);
inner=min(inner,length(p)-holeSize);
mask*=1.0-fxCover(inner,softness)*detailAmount;
return sat(mask);
}
}