// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

         // ValueNoise: 缩放P0 八度P1
    return ref_fbmG(uv * refP0, int(refP1), 0.5);
