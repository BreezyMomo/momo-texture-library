// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float r = length(p);
    float a = atan(p.y, p.x);
    float r0 = max(refP0, 0.10);
    float w = max(refP3, 0.002);
    float v = 1.0 - ref_smoothstep(w * 0.6, w * 1.4, abs(r - r0));
    float n = floor(max(refP1, 6.0));
    float seg = 6.28318530718 / n;
    float k = floor(a / seg);
    float ac = (k + 0.5) * seg;
    // 每根火舌有独立相位与长度 → 火焰跳动
    float h = ref_hash1(vec2(k, 7.7));
    float flick = 0.62 + 0.38 * sin(time * max(refP4, 0.0) * 3.0 + h * 6.28318530718);
    float len = max(refP2, 0.02) * (0.45 + h) * flick;
    float ang = abs(a - ac) * r0;
    float d = length(vec2(max(ang - w * 1.5, 0.0),
                          max(abs(r - (r0 - len * 0.5)) - len * 0.5, 0.0)));
    v = max(v, 1.0 - ref_smoothstep(0.004, 0.011, d));
    return clamp(v, 0.0, 1.0);
