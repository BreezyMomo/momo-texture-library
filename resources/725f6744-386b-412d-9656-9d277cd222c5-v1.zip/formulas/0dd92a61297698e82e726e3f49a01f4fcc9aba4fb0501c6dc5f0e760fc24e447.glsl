{
float petalCount = a.x;
float flowerScale = a.y;
float petalLength = a.z;
float petalWidth = a.w;
float petalOffset = b.x;
float petalPower = b.y;
float centerSize = b.z;
float holeSize = b.w;
float stamenCount = c.x;
float stamenLength = c.y;
float detailAmount = c.z;
float rotationDeg = c.w;
float softness = d.x;
{
vec2 p=q/max(flowerScale,0.01);
float n=floor(petalCount+0.5);
float rotation=rotationDeg*PI/180.0;
float dist=fxPetal(p,n,0.0,rotation,petalOffset,petalWidth,petalLength,petalPower);
dist=min(dist,length(p)-centerSize);
float mask=fxCover(dist,softness);
float stamens=fxStamens(p,floor(stamenCount+0.5),stamenLength,holeSize,rotation,0.000,0.008,0.021);
mask*=1.0-fxCover(stamens,softness)*detailAmount;
return sat(mask);
}
}