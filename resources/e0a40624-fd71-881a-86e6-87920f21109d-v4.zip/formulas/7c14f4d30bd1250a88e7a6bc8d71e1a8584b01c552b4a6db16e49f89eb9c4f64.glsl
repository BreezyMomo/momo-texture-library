// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float r = length(p);
    float a = mod(atan(p.y, p.x) + time * refP4, 6.28318530718);
    float n = floor(max(refP1, 4.0));
    float seg = 6.28318530718 / n;
    float ash = a + 3.14159265359 * 4.0;
    float k = floor(ash / seg);
    float ac = (k + 0.5) * seg;
    k = mod(k, n); // Stable glyph identity around the closed ring.
    float rr = max(refP0, 0.10);
    float wid = seg * rr * max(refP2, 0.1) * 0.5;
    float hgt = max(refP3, 0.02);
    vec2 lc = vec2((ash - ac) * rr, r - rr);
    float h1 = ref_hash1(vec2(k, 2.7));
    float h2 = ref_hash1(vec2(k, 5.1));
    float h3 = ref_hash1(vec2(k, 8.3));
    // 方框字形 + 3 条随机笔画（方块字式的「符文」观感）
    float v = ref_strokeD(ref_sdBox(lc, vec2(wid, hgt)), 0.004, 0.003);
    v = max(v, ref_strokeD(ref_sdSeg(lc, vec2(-wid, (h1 - 0.5) * hgt * 1.2),
                             vec2(wid, (h1 - 0.5) * hgt * 1.2)), 0.005, 0.003));
    v = max(v, ref_strokeD(ref_sdSeg(lc, vec2((h2 - 0.5) * wid * 1.6, -hgt),
                             vec2((h2 - 0.5) * wid * 1.6, hgt)), 0.005, 0.003));
    v = max(v, ref_strokeD(ref_sdSeg(lc, vec2(-wid * 0.8, (h3 - 0.5) * hgt),
                             vec2(0.0, 0.0)), 0.005, 0.003));
    return clamp(v, 0.0, 1.0);
