// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float r = length(p);
    float a = mod(atan(p.y, p.x) + time * refP5, 6.28318530718);
    float w = max(refP4, 0.0018);
    float r0 = max(refP0, 0.20);
    float r1 = r0 * 0.74;
    float v = 1.0 - ref_smoothstep(w * 0.6, w * 1.4, abs(r - r0));
    v = max(v, 1.0 - ref_smoothstep(w * 0.6, w * 1.4, abs(r - r1)));
    // 双环之间的刻度
    float nt = floor(max(refP2, 4.0));
    float sert = 6.28318530718 / nt;
    float kt = floor(a / sert + 0.5);
    float act = kt * sert;
    float len1 = (r0 - r1) * 0.70;
    float dd = length(vec2(max(abs(a - act) * r0 - w * 0.9, 0.0),
                           max(abs(r - (r1 + len1 * 0.5)) - len1 * 0.5, 0.0)));
    v = max(v, 1.0 - ref_smoothstep(0.004, 0.010, dd));
    // 内接多边形
    float np = floor(max(refP1, 3.0));
    float segp = 6.28318530718 / np;
    float rp = r1 * 0.84;
    v = max(v, ref_strokeD(cos(floor(0.5 + a / segp) * segp - a) * r - rp, w * 0.9, 0.003));
    // 内层符文带
    float nr = floor(max(refP3, 6.0));
    float serr = 6.28318530718 / nr;
    float kr = floor(a / serr);
    float acr = (kr + 0.5) * serr;
    kr = mod(kr, nr);
    float rmid = r1 * 0.52;
    vec2 lc = vec2((a - acr) * rmid, r - rmid);
    float bw = serr * rmid * 0.40;
    float bh = r1 * 0.17;
    float h1 = ref_hash1(vec2(kr, 2.7));
    float h2 = ref_hash1(vec2(kr, 5.1));
    v = max(v, ref_strokeD(ref_sdSeg(lc, vec2(-bw, (h1 - 0.5) * bh * 2.0),
                             vec2(bw, (h1 - 0.5) * bh * 2.0)), 0.004, 0.003));
    v = max(v, ref_strokeD(ref_sdSeg(lc, vec2((h2 - 0.5) * bw * 2.0, -bh),
                             vec2((h2 - 0.5) * bw * 2.0, bh)), 0.004, 0.003));
    return clamp(v, 0.0, 1.0);
