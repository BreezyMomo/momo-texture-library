// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float r = length(p);
    float a = mod(atan(p.y, p.x) + time * refP4, 6.28318530718);
    float n = floor(max(refP1, 4.0));
    float seg = 6.28318530718 / n;
    float k = floor(a / seg);
    float ac = (k + 0.5) * seg;
    k = mod(k, n);
    float rr = max(refP0, 0.10);
    vec2 lc = vec2((a - ac) * rr, r - rr);
    float cw = seg * rr * 0.5 * max(refP2, 0.1);
    float ch = max(refP3, 0.02);
    float hb = ref_hash1(vec2(k, 3.3));
    // 3×3 点阵字符（数字滚屏式的符文）
    float v = 0.0;
    for(int iy = 0; iy < 3; iy++){
      for(int ix = 0; ix < 3; ix++){
        float bit = ref_hash1(vec2(float(ix) * 7.13 + float(iy) * 3.7 + hb * 5.0, k));
        float on = step(0.46, bit);
        vec2 c = vec2((float(ix) - 1.0) * cw, (float(iy) - 1.0) * ch);
        v = max(v, on * (1.0 - ref_smoothstep(cw * 0.15, cw * 0.42, length(lc - c))));
      }
    }
    // 外围细环
    v = max(v, 1.0 - ref_smoothstep(0.0025, 0.007, abs(r - (rr + ch * 1.05))));
    return clamp(v, 0.0, 1.0);
