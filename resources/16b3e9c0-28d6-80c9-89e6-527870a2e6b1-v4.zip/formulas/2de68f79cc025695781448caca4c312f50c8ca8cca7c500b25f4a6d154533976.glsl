// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float n = floor(max(refP0, 3.0));
    float seg = 3.14159265359 / n;                  // 2n 个顶点，内外半径交替
    float rIn = max(refP1, 0.05);
    float rOut = max(refP2, rIn + 0.05);
    float w = max(refP3, 0.0018);
    // 真·星形：相邻顶点（外/内交替）直连成 2n 条边
    float v = 0.0;
    for(int i = 0; i < 20; i++){
      if(float(i) >= n * 2.0) break;
      float a0 = seg * float(i);
      float a1 = seg * (float(i) + 1.0);
      float q0 = mod(float(i), 2.0);
      float q1 = mod(float(i) + 1.0, 2.0);
      vec2 A = vec2(cos(a0), sin(a0)) * mix(rIn, rOut, q0);
      vec2 B = vec2(cos(a1), sin(a1)) * mix(rIn, rOut, q1);
      v = max(v, ref_strokeD(ref_sdSeg(p, A, B), w, 0.003));
    }
    if(refP4 > 0.02){
      v = max(v, ref_strokeD(length(p) - refP4, w, 0.003));
    }
    return clamp(v, 0.0, 1.0);
