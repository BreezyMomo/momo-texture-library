{
float petalCount = a.x;
float flowerScale = a.y;
float petalLength = a.z;
float petalWidth = a.w;
float petalOffset = b.x;
float petalPower = b.y;
float centerSize = b.z;
float holeSize = b.w;
float detailAmount = c.x;
float rotationDeg = c.y;
float softness = c.z;
{
vec2 p=q/max(flowerScale,0.01);
float n=floor(petalCount+0.5);
float rotation=rotationDeg*PI/180.0;
float dist=fxPetal(p,n,0.0,rotation,petalOffset,petalWidth,petalLength,petalPower);
dist=min(dist,length(p)-centerSize);
float mask=fxCover(dist,softness);
float inner=fxPetal(p,12.0,0.0,rotation,0.205,0.065,0.075,2.0);
inner=min(inner,length(p)-0.205);
mask*=1.0-fxCover(inner,softness)*detailAmount;
mask=max(mask,fxCover(length(p)-holeSize,softness));
return sat(mask);
}
}