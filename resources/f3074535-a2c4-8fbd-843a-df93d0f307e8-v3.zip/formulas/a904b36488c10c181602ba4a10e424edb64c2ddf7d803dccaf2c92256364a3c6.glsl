// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float r = length(p);
    float a = atan(p.y, p.x) + refP3;
    float n = floor(max(refP0, 3.0));
    float seg = 6.28318530718 / n;
    float rr = max(refP1, 0.05);
    float w = max(refP4, 0.0018);
    // 正多边形边
    float v = ref_strokeD(cos(floor(0.5 + a / seg) * seg - a) * r - rr, w, 0.003);
    // 顶点之间的弦（跨度 1 = 画回多边形本身，2 以上 = 星形连线）
    float st = floor(clamp(refP2, 1.0, max(n - 1.0, 1.0)));
    for(int i = 0; i < 12; i++){
      if(float(i) >= n) break;
      float a0 = seg * float(i) + refP3;
      float a1 = seg * (float(i) + st) + refP3;
      vec2 A = vec2(cos(a0), sin(a0)) * rr;
      vec2 B = vec2(cos(a1), sin(a1)) * rr;
      v = max(v, ref_strokeD(ref_sdSeg(p, A, B), w, 0.003));
    }
    return clamp(v, 0.0, 1.0);
