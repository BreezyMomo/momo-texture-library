// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    vec2 q = abs(p);
    float r0 = max(refP0, 0.06);
    float w = max(refP3, 0.0018);
    // 方形环
    float v = ref_strokeD(ref_sdBox(p, vec2(r0)), w, 0.003);
    // 中央十字（长度按方环半径比例）
    float len = r0 * max(refP1, 0.05);
    float inRange = 1.0 - ref_smoothstep(len, len + 0.03, max(q.x, q.y));
    v = max(v, ref_strokeD(min(q.x, q.y), w * max(refP2, 0.15), 0.003) * inRange);
    // 四角结点
    v = max(v, 1.0 - ref_smoothstep(w * 2.2, w * 4.6, length(q - vec2(r0))));
    return clamp(v, 0.0, 1.0);
