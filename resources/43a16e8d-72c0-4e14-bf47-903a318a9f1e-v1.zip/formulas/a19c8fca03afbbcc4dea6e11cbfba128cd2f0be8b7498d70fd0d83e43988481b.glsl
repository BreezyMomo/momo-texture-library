{
float petalCount = a.x;
float flowerScale = a.y;
float petalLength = a.z;
float petalWidth = a.w;
float petalOffset = b.x;
float petalPower = b.y;
float swirl = b.z;
float centerSize = b.w;
float holeSize = c.x;
float stamenCount = c.y;
float stamenLength = c.z;
float detailAmount = c.w;
float rotationDeg = d.x;
float softness = d.y;
{
vec2 p=q/max(flowerScale,0.01);
float n=floor(petalCount+0.5);
float rotation=rotationDeg*PI/180.0;
float dist=fxPetal(p,n,swirl,rotation,petalOffset,petalWidth,petalLength,petalPower);
dist=min(dist,length(p)-centerSize);
float mask=fxCover(dist,softness);
float radius=length(p);
float theta=atan(p.y,p.x)-rotation+swirl*radius*2.0;
float seam=radius*abs(cos(theta*n*0.5))/max(n*0.5,1.0);
float seamWidth=0.010*(0.7+0.3*smoothstep(0.05,0.5,radius));
mask*=1.0-fxCover(seam-seamWidth,softness)*detailAmount;
float stamens=fxStamens(p,floor(stamenCount+0.5),stamenLength,holeSize,rotation,-0.700,0.008,0.021);
mask*=1.0-fxCover(stamens,softness)*detailAmount;
return sat(mask);
}
}