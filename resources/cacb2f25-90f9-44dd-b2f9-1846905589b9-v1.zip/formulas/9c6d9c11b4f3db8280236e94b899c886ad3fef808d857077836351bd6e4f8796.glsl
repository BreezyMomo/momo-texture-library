{
float petalCount = a.x;
float flowerScale = a.y;
float petalLength = a.z;
float petalWidth = a.w;
float petalOffset = b.x;
float petalPower = b.y;
float notchDepth = b.z;
float rotationDeg = b.w;
float softness = c.x;
{
vec2 p=q/max(flowerScale,0.01);
float n=floor(petalCount+0.5);
float rotation=rotationDeg*PI/180.0;
float dist=fxPetal(p,n,0.0,rotation,petalOffset,petalWidth,petalLength,petalPower);
float heart=fxHeartPetal(p,n,0.0,rotation,petalOffset,petalWidth,petalLength);
dist=mix(dist,heart,clamp(notchDepth/0.055,0.0,1.0));
float mask=fxCover(dist,softness);
return sat(mask);
}
}