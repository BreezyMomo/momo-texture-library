// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    vec2 q = (uv - 0.5) * refP0 * vec2(max(refP1, 0.02), max(refP2, 0.02));
    return ref_fbmP(q, int(refP3), 0.5);
