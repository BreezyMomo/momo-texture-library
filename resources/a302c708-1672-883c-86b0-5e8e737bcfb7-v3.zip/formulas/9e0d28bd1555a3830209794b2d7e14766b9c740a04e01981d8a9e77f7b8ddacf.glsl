// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    vec2 q = ref_rot2(p, -refP3);
    float r = length(q);
    float a = atan(q.y, q.x);
    float rr = max(refP0, 0.15);
    float w = max(refP2, 0.0018);
    float v = 1.0 - ref_smoothstep(w * 0.5, w * 1.2, abs(r - rr));
    // 六角骨架：3 条过中心的直线
    for(int i = 0; i < 3; i++){
      float aa = 3.14159265359 * float(i) / 3.0;
      vec2 d = vec2(cos(aa), sin(aa));
      float dist = abs(ref_cross2(q, d));
      float inb = 1.0 - ref_smoothstep(rr * 0.86, rr * 1.04, r);
      v = max(v, (1.0 - ref_smoothstep(w * 0.5, w * 1.1, dist)) * inb);
    }
    // 外围冰刺
    float n = floor(max(refP1, 6.0));
    float seg = 6.28318530718 / n;
    float k = floor(a / seg + 0.5);
    float ac = k * seg;
    float len = rr * 0.24 * (0.55 + ref_hash1(vec2(k, 3.1)));
    float dd = length(vec2(max(abs(a - ac) * rr - w, 0.0),
                           max(abs(r - (rr + len * 0.5)) - len * 0.5, 0.0)));
    v = max(v, 1.0 - ref_smoothstep(0.004, 0.010, dd));
    return clamp(v, 0.0, 1.0);
