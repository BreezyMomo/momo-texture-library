// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float r = length(p);
    float n = floor(max(refP1, 1.0));
    float gap = max(refP2, 0.02);
    float w = max(refP3, 0.0015);
    float v = 0.0;
    for(int i = 0; i < 6; i++){
      if(float(i) >= n) break;
      float ri = max(refP0, 0.05) - float(i) * gap;
      if(ri <= 0.03) break;
      v = max(v, 1.0 - ref_smoothstep(w, w * 2.2, abs(r - ri)));
      // 最外环做双线（法阵典型的「双圈」描边）
      if(i == 0){
        v = max(v, 1.0 - ref_smoothstep(w * 0.8, w * 1.8,
                      abs(r - (ri - max(w * 4.5, 0.022)))));
      }
    }
    return clamp(v, 0.0, 1.0);
