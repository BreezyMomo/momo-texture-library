// Adapted from EasyCG TexForge; see reference-migration.json.
return dot(ref_vector_RadialFlow(q,u,a,b,time),vec3(.299,.587,.114));
