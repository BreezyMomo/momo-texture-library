// Adapted from EasyCG TexForge; see reference-migration.json.
vec2 p=q,uv=u;
float refP0=a.x;
float refP1=a.y;
float refP2=a.z;
float refP3=a.w;
float refP4=b.x;
float refP5=b.y;
float refP6=b.z;
float refP7=b.w;

    float x = abs(uv.x - 0.5);
    float cw = max(refP0, 0.008);
    float gw = max(refP1, cw + 0.02);
    float core = 1.0 - ref_smoothstep(cw * 0.45, cw, x);
    float glow = 1.0 - ref_smoothstep(gw * 0.28, gw, x);
    float y = clamp(uv.y, 0.0, 1.0);
    float hold = clamp(refP3, 0.0, 0.85);
    float base = clamp(y / max(hold + 0.02, 0.03), 0.0, 1.0);
    float along = mix(pow(base, max(refP2, 0.05)), 1.0, ref_smoothstep(hold - 0.02, hold + 0.09, y));
    return clamp((core + glow * 0.55) * along, 0.0, 1.0);
